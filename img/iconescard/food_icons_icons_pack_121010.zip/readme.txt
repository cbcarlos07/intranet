Hi, thank you for downloading this iconset:)
Please, tell me about commercial use my icons - 1170632@gmail.com
Enjoy!:)

Anna
http://iloveicons.ru